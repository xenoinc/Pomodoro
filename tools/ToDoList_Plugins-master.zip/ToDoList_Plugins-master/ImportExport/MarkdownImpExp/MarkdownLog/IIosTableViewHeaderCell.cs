namespace MarkdownLog
{
    public interface IIosTableViewHeaderCell : IIosTableViewCell
    {
    }
}