namespace MarkdownLog
{
    public enum TableColumnAlignment
    {
        Unspecified,
        Left,
        Center,
        Right
    }
}