﻿namespace MarkdownLog
{
    public enum TableViewCellAccessory
    {
        None,
        DisclosureIndicator,
        DetailDisclosureButton,
        Checkmark,
        DetailButton,
    }
}